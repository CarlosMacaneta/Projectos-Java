package views;

/**
 *
 * @author CarlosMacaneta
 */
public class EditarDoador {
    
}
